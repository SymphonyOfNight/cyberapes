/**
 * 全局常量
 * @type {{}}
 */
const Global = {
    BASE_URL: "gateway/",
    LOGIN_USER: "apesLoginUser",
    APES_LOGIN_REMEMBER_ME: "APES_LOGIN_REMEMBER_ME",
}

export default Global