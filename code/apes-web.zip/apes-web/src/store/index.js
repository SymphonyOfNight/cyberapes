/**
 * 统一常量入口
 */
export * from './global'

