<template>
    <el-container>
        <el-header class="top">
            <el-container>
                <el-main class="top-main">
                    header-main
                </el-main>
            </el-container>
        </el-header>
        <el-main>
            <el-container>



            </el-container>
        </el-main>
        <el-footer>
            <el-container>
                <el-main class="footer-about">
                    about
                </el-main>
                <el-footer height="30" class="footer-copyright">
                    copyright info.
                </el-footer>
            </el-container>
        </el-footer>
    </el-container>
</template>

<script>
    export default {
        name: "LoginLayout"
    }
</script>

<style scoped>

</style>