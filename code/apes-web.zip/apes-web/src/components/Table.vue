<template>
    <el-table>

    </el-table>
</template>

<script>
    export default {
        name: "Table"
    }
</script>

<style scoped>

</style>