<template>
    <IndexLayout>
        <div>123123123123</div>
    </IndexLayout>
</template>

<script>
    import IndexLayout from "../../components/layout/IndexLayout";
    export default {
        name: "Index",
        components: {IndexLayout}
    }
</script>

<style scoped>

</style>